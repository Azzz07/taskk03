sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("list.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);